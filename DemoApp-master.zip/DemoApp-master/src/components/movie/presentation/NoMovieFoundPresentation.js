/**
 * Created by gouravpal on 15/05/17.
 */
import React from 'react';
//Presentational component, if no movies are found
const NoMovieFoundPresentation=()=>{
  return(
    <div>
      <h1>Oops! movies not found.</h1>
    </div>
  );
};

export default NoMovieFoundPresentation;
