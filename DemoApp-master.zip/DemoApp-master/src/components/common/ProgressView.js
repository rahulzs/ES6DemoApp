/**
 * Created by gouravpal on 11/05/17.
 */
import React, {PropTypes} from 'react';

/*It's a common presentational component, can be used to show progress bar in the screen.*/
const ProgressView = () => {

  return (
   <div className="loader"></div>

  );
};



export default ProgressView;
