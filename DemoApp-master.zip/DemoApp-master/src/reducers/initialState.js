/**
 * Created by gouravpal on 13/05/17.
 */

/*
* initialStates passed in reducers. It indicates the basic structure of Redux store.
* */
export default {
  movies: {isLoading: false},
  movie: {isLoading: false}
};
