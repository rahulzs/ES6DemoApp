/**
 * Created by gouravpal on 13/05/17.
 */
/*constants for actions*/
export const LOAD_MOVIES_SUCCESS='LOAD_MOVIES_SUCCESS';
export const LOAD_MOVIES_BEGIN='LOAD_MOVIES_BEGIN';
export const LOAD_MOVIE_BY_ID_SUCCESS='LOAD_MOVIE_BY_ID_SUCCESS';
export const LOAD_MOVIE_BY_ID_BEGIN='LOAD_MOVIE_BY_ID_BEGIN';
