/**
 * Created by GP00471911 on 10-05-2017.
 */
import colors from 'colors';
/* eslint-disable no-console*/
console.log('Starting app in dev mode...'.green);
